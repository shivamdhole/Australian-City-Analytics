
# Team 25

# Qiushi Zhou : 714916
# Yifeng Zhu : 764 991
# Naman Gupta: 774996
# Shivam Dhole: 741507
# Abhishek Sirohi: 727644

import nltk
from nltk.corpus import stopwords
from textblob import TextBlob
import re

import tweepy
import json
import couchdb

import sys
import time

wnl = nltk.WordNetLemmatizer()
stopwords = set(stopwords.words('english'))
dictionary = set(nltk.corpus.words.words())

def getHashtagWords(hashtag, dictionary):
    matches=[]

    # try a word from the vocabulary
    dynamicString=""
    
    for char in hashtag:
        dynamicString +=char
        if dynamicString in dictionary and dynamicString in dictionary != None :
            matches.append(dynamicString)
    if len(matches) >0:
        return matches

   # try a number, a sequence of digits
    dynamicString=""
    for char in hashtag:
        if char.isdigit() :
            dynamicString +=char
            matches.append(dynamicString)
        else :
            break
    if len(matches) >0:
        return matches
    
  #  try a sequence of seperators
    dynamicString=""
    for c in hashtag:
        if c in ['=','^','*','%','$','@','-','_','+','&',' ','|','#', '!','?',')',']','[','(','/']:
            dynamicString +=c
            matches.append(dynamicString)
        else:
            break
    if len(matches) >0:
        return matches
    return matches


def maxmatch(hashtag, dictionary):
    matches=[]
    dynamicString = hashtag
    while len(dynamicString) > 0:
        word_list = getHashtagWords(dynamicString, dictionary)
        if (len(word_list) < 1):
            break;
        this_part = word_list[-1]
        l=len(this_part)
        matches.append(this_part)
        dynamicString=dynamicString[(l):]
    return ' '.join(matches)


def removestopwords(tweet):
    words=[]
    for t in tweet:
        if t not in stopwords:
            words.append(t)
    return ' '.join(words)

def preprocess(tweet):
    tweet = re.sub(r'(?:\@|https?\://)\S+',"",tweet,0)#remove url
    tweet = re.sub(r'(?<=^|(?<=[^a-zA-Z0-9-_\\.]))@([A-Za-z]+[A-Za-z0-9_]+)',"",tweet,0)# remove username
    topics=re.findall(r'\B#\w*[a-zA-Z]+\w*',tweet)
    tweet = re.sub(r'(?<=^|(?<=[^a-zA-Z0-9-_\\.]))#([A-Za-z]+[A-Za-z0-9_]+)',"",tweet,0)#remove hashtag
    tweet = tweet.lower()
    for topic in topics:
        topic = topic.strip('#')
        tweet = tweet + maxmatch(topic,dictionary)
    strtweet = removestopwords(tweet.split())
    return strtweet

if __name__ == '__main__':
    
    #get the argument from command line
    try:
        host = sys.argv[1]
    except Exception as e:
        print "usage: tweetHarvest_search.py <host>"
        sys.exit()
        
    #twitter account3   
    auth = tweepy.OAuthHandler("L8CUcgfTUFGVfXNnNbytSW5SU", "UYrwzRlx7Y2l5w6Xlc2lSADcCK98Gyfi4fdEpQXMi6hl9WyCHp")
#   auth.set_access_token("720916560815136769-lt17MOzXr4yQvdiJzXmdBW7jV2zdMZ3", "gK3xt7GuaHmqnQ10ffZI9bQm7Rwxc5eYn9LhQVhomSGLj")

    
    api = tweepy.API(auth,wait_on_rate_limit=True)

    couch = couchdb.Server() 
    try:
        host = 'http://' + str(host) +':5984/'
        #couch = couchdb.Server('http://146.118.99.24:5984/')
        couch = couchdb.Server(host)
        # select database
        db_tweets = couch['tweets']
        db_twitters = couch['twitters']
        
    except Exception as e:
        print "Couldn't connect the host, please check the input."
        sys.exit()
        
    print "Harvesting tweets to couchdb... ..."
    
    while True:
        try:
            results = api.search(geocode="-37.7443,145.1025,18km",count=100)    
        except tweepy.TweepError as e:
            #twitter server internal error
            if e.message[0]['code']==131:
                time.sleep(60*5)        
        
        for result in results:
            tw_json = result._json
            sentiment = TextBlob(preprocess(tw_json["text"])).polarity
            #set the id as tweet id
            tw_json["_id"] = tw_json["id_str"]
            #add sentiment score to the tweet json
            tw_json["sentiment"] = sentiment
            
            try:
                #save the captured tweet
                db_tweets.save(tw_json)
                
                ur_json={}
                #save the user of the tweet
                ur_json["_id"] = tw_json["user"]["id_str"]
    
                db_twitters.save(ur_json)

            except Exception as e:
                if e.message[0]=="conflict":
                    pass
                else:
                    print e.message
                    pass
                
