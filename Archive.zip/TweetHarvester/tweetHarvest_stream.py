
# Team 25

# Qiushi Zhou : 714916
# Yifeng Zhu : 764 991
# Naman Gupta: 774996
# Shivam Dhole: 741507
# Abhishek Sirohi: 727644

import tweepy
import json
import couchdb
import time

import sys
# This is the listener, resposible for receiving data
class StdOutListener(tweepy.StreamListener):
    #get the argument from command line
    try:
        host = sys.argv[1]
    except Exception as e:
        print "usage: tweetHarvest_search.py <host>"
        sys.exit()
    
    try:
        host = 'http://' + str(host) +':5984/'
        #couch = couchdb.Server('http://146.118.99.24:5984/')
        couch = couchdb.Server(host)
        # select database
        db = couch['tweets']
    
    except Exception as e:
        print "Couldn't connect the host, please check the input."
        sys.exit()
        

    def on_data(self, data):

        decoded = json.loads(data)
        decoded["_id"] = decoded["id_str"]
        try:
            self.db.save(decoded)
            
        except Exception as e:
            if e.message[0]=="conflict":
                pass
            else:
                print e.message()    
                    
        return True

    def on_error(self, status):
        print status

if __name__ == '__main__':
    
    
    l = StdOutListener()
    auth = tweepy.OAuthHandler("Vb1JJPjb3xR0TA9SjDOcq8u1d", "uC6qBFCVvhu1jxS2EuVuXCQp89vIs558xyyy1B6N8BVoAtmyLP")
    auth.set_access_token("720916560815136769-lt17MOzXr4yQvdiJzXmdBW7jV2zdMZ3", "gK3xt7GuaHmqnQ10ffZI9bQm7Rwxc5eYn9LhQVhomSGLj")

    print "Harvesting tweets to couchdb... ..."

    # There are different kinds of streams: public stream, user stream, multi-user streams
    # For more details refer to https://dev.twitter.com/docs/streaming-apis
    try:
        stream = tweepy.Stream(auth, l)
        #topleft of mel:-37.456693, 144.406549    bottomright of melbourne:-38.211570, 145.571099
        stream.filter(locations=[144.42,-38.21,145.58,-37.61])
    except tweepy.TweepError as e:
        #twitter server internal error
        if e.message[0]['code']==131:
            time.sleep(60*5)
