To execute the program, modify the content of AutoDeploymentPhase1.py. 

Change line 52: "testHost = "/home/qiushi/testHost" to a host file desired.

In line 56: change "ansible_ssh_private_key_file=/home/qiushi/shivam.pem" to the location of your SSH private key.

Type command: python AutoDeploymentPhase1.py

Type command: ansible-playbook -i [the host file name you specified before] playbook1.yml


