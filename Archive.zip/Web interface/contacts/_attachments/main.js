

db = $.couch.db("suburb");

function updatecontacts(sub,score1,callback) {
    console.log("Called updatecontacts");

    db.view("suburb/suburbstory", {
        success: function(data) {
           
            for (i in data.rows) {
                sub[i] = data.rows[i].value.suburb;
                score1[i] = data.rows[i].value.story1*100;
                    
            }
             if(callback != null && callback != undefined){
              callback(sub,score1);
            
        }   
    }});
    
    console.log("Finished updatecontacts");
}



function go() {
    console.log("Called go");

    var locations=1;
    var allcoords=[];
    var scores=[];
    var names=[];
    var scoreclassify=[];
    var xmlhttp = new XMLHttpRequest();
    var url = "data.json";
    var sub=[];
    var score1=[];

    updatecontacts(sub,score1,function(sub,score1){
            
            xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    var count=0;
                    var areas=[];
                    var arr1 = JSON.parse(xmlhttp.responseText);
            
                    locations=arr1.features.length;
                    while(count++!=locations){
                     areas=[];   
            
                    var arr = (arr1.features[count-1].geometry.coordinates[0])[0];
                    var name= arr1.features[count-1].properties.feature_name;
                    var score= arr1.features[count-1].properties.estimate;
                        
                    for(var i=0;i<arr.length;i++){
                        var t = { lng: (arr[i])[0], lat: (arr[i])[1] };
                        areas.push(t); 
                    }
                        allcoords.push(areas);
                        names.push(name);
                        
                        scores.push(null);
                }
           
        
                }

        if(allcoords.length > 0){
              scorepush(names,scores,sub,score1, function(scores) {
            scoreclassify=[];
            displayscore(scores,scoreclassify, function(scoreclassify) {
                initMap(scores,locations,allcoords,names,scoreclassify, function() {
        
      });
  });
});
    }
                
            };
                xmlhttp.open("GET", url, true);
            xmlhttp.send();
            
    });
    

   console.log("Finished go");
 
    
}


          
        function scorepush(names,scores,sub,score1,callback) {
            console.log("Called scorepush");

            for(var i=0;i<sub.length;i++){
                for(var j=0;j<names.length;j++){
                    if(sub[i]==names[j]){
                        scores[j]=score1[i];
                    }     
                }
            }
            console.log("Finished scorepush:");
            if(callback != null && callback != undefined){
                callback(scores);
            }  
           
        }
            
        
        function displayscore(scores,scoreclassify,callback){
            
            console.log("Called displayscore");

            minscore=101;
            maxscore=0;

                for(var i=0;i<scores.length;i++){
                if(scores[i]<minscore && scores[i]!=null){
                    minscore=scores[i];
                }
                if(scores[i]>maxscore && scores[i]!=null)
                    maxscore=scores[i];
                }

                var gap = (maxscore-minscore)/4;
                var temp= minscore;
                for(var i=1;i<=4;i++){
                    scoreclassify[i-1]=parseFloat((temp+gap).toFixed(2));
                    document.getElementById("legend"+i).innerHTML+= temp+" - "+scoreclassify[i-1];
                   temp = parseFloat((temp+gap).toFixed(2)); 
                }


                document.getElementById("sign1").getContext("2d").fillStyle="rgba(255,153,153,1)";
                document.getElementById("sign2").getContext("2d").fillStyle="rgba(255,77,77,1)";
                document.getElementById("sign3").getContext("2d").fillStyle="rgba(255,0,0,1)";
                document.getElementById("sign4").getContext("2d").fillStyle="rgba(179,0,0,1)";
                document.getElementById("sign5").getContext("2d").fillStyle="rgba(0,0,0,0.5)";
                document.getElementById("sign1").getContext("2d").fillRect(0,0,300,200);
                document.getElementById("sign2").getContext("2d").fillRect(0,0,300,200);
                document.getElementById("sign3").getContext("2d").fillRect(0,0,300,200);
                document.getElementById("sign4").getContext("2d").fillRect(0,0,300,200);
                document.getElementById("sign5").getContext("2d").fillRect(0,0,300,200);
                document.getElementById("legend").style.visibility="visible";

                console.log("Finished displayscore");

                 if(callback != null && callback != undefined){
                    callback(scoreclassify);
                }
          
        }
         
  
      function initMap(scores,locations,allcoords,names,scoreclassify,callback) {
        console.log("Called initmap");

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: {lat: -37.831, lng: 144.973},
          mapTypeId: google.maps.MapTypeId.TERRAIN
        });
          var infowindow = new google.maps.InfoWindow();
          var colortoput;
         
          for(var i=0;i<locations;i++){
               
            if(scores[i]!=null){
                  if(scores[i]<scoreclassify[1])
                      colortoput='rgba(255,153,153,1)';
                  else if(scores[i]<scoreclassify[2])
                      colortoput='rgba(255,77,77,1)';
                  else if(scores[i]<scoreclassify[3])
                      colortoput='rgba(255,0,0,1)';
                  else if(scores[i]<=scoreclassify[4])
                      colortoput='rgba(179,0,0,1)';
                    else
                        colortopput='rgba(100,100,100,1)';
            }
            else
                colortoput='rgba(100,100,100,0.5)'
              
            var cont = "Name: "+names[i]+"<br> Score: "+scores[i];
              
              
            var bermudaTriangle = new google.maps.Polygon({
              paths: allcoords[i],
              strokeColor: '#FF0000',
              strokeOpacity: 0.8,
              strokeWeight: 2,
              fillColor: colortoput,
              fillOpacity: 0.5
            });
           
              
        
            bermudaTriangle.setMap(map);
            bindInfoWindow(bermudaTriangle, map, infowindow, cont); 
              
            google.maps.event.addListener(bermudaTriangle,"mouseover",function(){
                    this.setOptions({oldColor:this.fillColor});
                    this.setOptions({fillColor: "#0000FF"});
            }); 

            google.maps.event.addListener(bermudaTriangle,"mouseout",function(){
                this.setOptions({fillColor: this.oldColor});
            });
            
        }
        console.log("Finished initmaps");

        if(callback != null && callback != undefined){
            callback();
        }
         

    }
        
    function bindInfoWindow(marker, map, infowindow, html) {
        marker.addListener('click', function(evt) {
            infowindow.setPosition(evt.latLng)
            infowindow.setContent(html);
            infowindow.open(map, this);
        });
    } 
