
# Team 25

# Qiushi Zhou : 714916
# Yifeng Zhu : 764 991
# Naman Gupta: 774996
# Shivam Dhole: 741507
# Abhishek Sirohi: 727644

import boto
from boto.ec2.regioninfo import RegionInfo
import time

# Start a EC2 connection

region=RegionInfo(name='melbourne-qh2', endpoint='nova.rc.nectar.org.au')
ec2_conn = boto.connect_ec2(aws_access_key_id='269f7f31e89c420785913cd9e0763809', 
		aws_secret_access_key='9860b5a185b2459292f8dfff8ec8d3cd', is_secure=True, region=region, port=8773, 
			path='/services/Cloud', validate_certs=False)

# Create 4 instances

num_instance = 4
for i in range(num_instance):
	ec2_conn.run_instances('ami-000022b3', key_name='Shivam', instance_type='m1.medium', security_groups=['default','http','ssh'])

# Create and get volume

vol = ec2_conn.create_volume(100,"melbourne-qh2")
volumes = ec2_conn.get_all_volumes()

# Wait 20 minutes for the instances to get ready 

time.sleep(1200)

# Get the running instances from the EC2 connection

reservations = ec2_conn.get_all_reservations()
instances = [i for r in reservations for i in r.instances]

# Get the information of all the instances

instance_ips = [i.ip_address for i in instances]
instSta = [i.state for i in instances]

# Attach volume to the 1st instance

ec2_conn.attach_volume(volumes[0].id,instances[0].id,"/dev/vdc")

# Generate a file with host information for Ansible

testHost = "/home/qiushi/testHost"
with open(testHost, 'w') as f:
	output = "[host1]\n"+instance_ips[0]+"\n\n[host2]\n"+instance_ips[1]+"\n\n[host3]\n"+instance_ips[2]+"\n\n[host4]\n"+instance_ips[3]+
	"\n\n[hosts]\n"+instance_ips[0]+"\n"+instance_ips[1]+"\n"+instance_ips[2]+"\n"+instance_ips[3]+
	"\n\n[hosts:vars]\nansible_ssh_user=ubuntu\nansible_ssh_private_key_file=/home/qiushi/shivam.pem\nip1="+instance_ips[0]+"\nip2="+instance_ips[1]+"\nip3="+instance_ips[2]+"\nip4="+instance_ips[3]
	f.write(output)
